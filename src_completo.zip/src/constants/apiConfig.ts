export const STT_API_KEY = process.env.STT_API_KEY || '';
export const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
export const STT_URL = 'https://api.deepgram.com/v1/listen';
