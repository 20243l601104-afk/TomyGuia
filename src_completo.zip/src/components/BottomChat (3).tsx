import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, Alert } from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, NEEDS_KEYWORDS, WANTS_KEYWORDS } from '../constants';
import { OPENAI_API_KEY } from '../constants/apiConfig';
import { IncomeAllocationModal } from './IncomeModal';
import type { Allocation, FixedExpenseSeed } from '../types';

/* ─── NLP Parser ─── */

function parseAmount(msg: string): number {
  const cleaned = msg.replace(/,/g, '');
  const kMatch = cleaned.match(/(\d+(?:\.\d+)?)\s*[kK]/);
  if (kMatch) return parseFloat(kMatch[1]) * 1000;
  const milMatch = cleaned.match(/(\d+(?:\.\d+)?)\s*mil/i);
  if (milMatch) return parseFloat(milMatch[1]) * 1000;
  const nums = cleaned.match(/\d+(?:\.\d+)?/g);
  if (nums && nums.length > 0) return Math.max(...nums.map(n => parseFloat(n)));
  return 0;
}

function detectIntent(msg: string): 'income' | 'expense' | 'bill' | 'query' | 'unknown' {
  const m = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const incomeWords = ['recibi', 'sueldo', 'ingreso', 'cobre', 'me pagaron', 'me depositaron', 'me llego', 'gane', 'bono', 'quincena', 'nomina', 'freelance', 'venta', 'me transfirieron'];
  if (msg.startsWith('+') || incomeWords.some(w => m.includes(w))) return 'income';
  const billWords = ['pague', 'ya pague', 'abone', 'cubri', 'pagar'];
  if (billWords.some(w => m.includes(w))) return 'bill';
  const expenseWords = ['gaste', 'compre', 'me costo', 'me cobro', 'pedi', 'fui a', 'comi en', 'tome un', 'uber', 'taxi', 'didi', 'cafe', 'comida', 'cena', 'almuerzo', 'desayuno'];
  if (msg.startsWith('-') || expenseWords.some(w => m.includes(w))) return 'expense';
  const queryWords = ['cuanto', 'tengo', 'balance', 'saldo', 'como voy', 'resumen', 'cuanto me queda', 'cuanto llevo'];
  if (queryWords.some(w => m.includes(w))) return 'query';
  if (parseAmount(msg) > 0) return 'expense';
  return 'unknown';
}

function detectCategory(msg: string): 'needs' | 'wants' {
  const m = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const needs = [...NEEDS_KEYWORDS, 'doctor', 'medicina', 'hospital', 'dentista', 'escuela', 'universidad', 'seguro', 'celular', 'telefono', 'mandado', 'leche', 'pan', 'huevo', 'tortilla', 'pollo', 'carne', 'verdura', 'fruta'];
  if (needs.some(k => m.includes(k))) return 'needs';
  const wants = [...WANTS_KEYWORDS, 'antojo', 'capricho', 'salida', 'vacaciones', 'viaje', 'juego', 'videojuego', 'zapatos', 'maquillaje', 'starbucks', 'oxxo', 'cerveza', 'vino', 'fiesta', 'concierto'];
  if (wants.some(k => m.includes(k))) return 'wants';
  return 'wants';
}

function extractLabel(msg: string): string {
  let label = msg.replace(/^[+\-]\s*/, '').replace(/\$?\d+[\d,.kK]*(mil)?/g, '').trim();
  if (label.length < 2) label = msg;
  return label.charAt(0).toUpperCase() + label.slice(1);
}

/* ─── Detectar gasto fijo por nombre ─── */
const BILL_ALIASES: Record<string, string[]> = {
  rent: ['renta', 'alquiler', 'arriendo'],
  water: ['agua'],
  light: ['luz', 'electricidad', 'electrica', 'cfe'],
  internet: ['internet', 'wifi', 'telefono', 'celular', 'telmex', 'izzi'],
  gas: ['gasolina', 'gas', 'tanque'],
  transport: ['transporte', 'camion', 'autobus', 'metro'],
  food: ['despensa', 'super', 'mandado', 'mercado', 'supermercado'],
  subs: ['suscripcion', 'suscripciones', 'netflix', 'spotify', 'streaming'],
};

function detectBill(msg: string, fixedExpenses: FixedExpenseSeed[]): FixedExpenseSeed | null {
  const m = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  for (const exp of fixedExpenses) {
    if (m.includes(exp.title.toLowerCase())) return exp;
    const aliases = BILL_ALIASES[exp.id];
    if (aliases && aliases.some(a => m.includes(a))) return exp;
  }
  return null;
}

/* ─── Componente ─── */

interface Props {
  onIncomeAdded?: (amount: number, allocation: Allocation) => void;
  onExpenseAdded?: (amount: number, category: 'needs' | 'wants', label: string) => void;
  onBillPaid?: (expenseId: string, title: string, amount: number) => void;
  fixedExpenses?: FixedExpenseSeed[];
  currentNeeds: number; currentWants: number; currentSavings: number; totalBalance: number;
}

const CHIPS = [
  { label: '+ $5000 Sueldo', type: 'income' },
  { label: '- $80 Cafe', type: 'expense' },
  { label: '- $150 Transporte', type: 'expense' },
  { label: '+ $100 Venta', type: 'income' },
];

export function BottomChat({ onIncomeAdded, onExpenseAdded, onBillPaid, fixedExpenses = [], currentNeeds, currentWants, currentSavings, totalBalance }: Props) {
  const [text, setText] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [incomeAmount, setIncomeAmount] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const recordingRef = useRef<Audio.Recording | null>(null);

  const showFeedback = (msg: string) => { setFeedback(msg); setTimeout(() => setFeedback(null), 3500); };

  const handleSend = () => {
    if (!text.trim()) return;
    const msg = text.trim(); setText(''); setIsFocused(false); setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      const amount = parseAmount(msg);
      const intent = detectIntent(msg);

      switch (intent) {
        case 'income':
          if (amount <= 0) { showFeedback('🤔 No entendi el monto. Intenta: "Recibi $5000"'); return; }
          setIncomeAmount(amount); setShowModal(true);
          break;

        case 'bill': {
          const bill = detectBill(msg, fixedExpenses);
          if (bill && onBillPaid) {
            const billAmount = amount > 0 ? amount : bill.amount;
            onBillPaid(bill.id, bill.title, billAmount);
            showFeedback(`✅ Pagaste ${bill.title}: $${billAmount.toLocaleString('es-MX')} · Descontado de Necesidades 🩷`);
          } else if (amount > 0 && onExpenseAdded) {
            const label = extractLabel(msg);
            onExpenseAdded(amount, 'needs', label);
            showFeedback(`✅ Necesidad: ${label} · $${amount.toLocaleString('es-MX')} 🩷`);
          } else {
            showFeedback('🤔 No encontre ese recibo. Intenta: "Pague la luz" o "Pague $200 de agua"');
          }
          break;
        }

        case 'expense':
          if (amount <= 0) { showFeedback('🤔 No entendi el monto. Intenta: "Gaste $200 en super"'); return; }
          if (onExpenseAdded) {
            const cat = detectCategory(msg);
            const label = extractLabel(msg);
            onExpenseAdded(amount, cat, label);
            showFeedback(`✅ ${cat === 'needs' ? 'Necesidad 🩷' : 'Gusto 💛'}: ${label} · $${amount.toLocaleString('es-MX')}`);
          }
          break;

        case 'query':
          showFeedback(`💰 Balance: $${totalBalance.toLocaleString('es-MX')}\n🩷 Necesidades: $${currentNeeds.toLocaleString('es-MX')}\n💛 Gustos: $${currentWants.toLocaleString('es-MX')}\n💚 Futuro: $${currentSavings.toLocaleString('es-MX')}`);
          break;

        default:
          showFeedback('🤔 Prueba: "Gaste $50 en cafe", "Pague la luz", "Recibi 5k", "Cuanto tengo?"');
      }
    }, 800);
  };

  /* ─── Voz ─── */
  const startRecording = async () => {
    try {
      const permission = await Audio.requestPermissionsAsync();
      if (!permission.granted) { showFeedback('❌ Se necesita permiso de microfono'); return; }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
      recordingRef.current = recording; setIsRecording(true);
      showFeedback('🎙️ Grabando... toca de nuevo para enviar');
    } catch (err) { showFeedback('❌ No se pudo iniciar la grabacion'); }
  };

  const stopAndTranscribe = async () => {
    if (!recordingRef.current) return;
    setIsRecording(false); setIsTranscribing(true); showFeedback('⏳ Transcribiendo...');
    try {
      await recordingRef.current.stopAndUnloadAsync();
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
      const uri = recordingRef.current.getURI(); recordingRef.current = null;
      if (!uri) { showFeedback('❌ No se grabo audio'); setIsTranscribing(false); return; }
      if (!OPENAI_API_KEY || OPENAI_API_KEY === 'TU_API_KEY_AQUI') { showFeedback('⚠️ Configura tu API key en apiConfig.ts'); setIsTranscribing(false); return; }
      const formData = new FormData();
      formData.append('file', { uri, type: 'audio/m4a', name: 'voice.m4a' } as any);
      formData.append('model', 'whisper-1'); formData.append('language', 'es');
      const response = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}` }, body: formData });
      const data = await response.json();
      if (data.text) { setText(data.text); inputRef.current?.focus(); showFeedback(`🎙️ "${data.text}"`); }
      else { showFeedback('❌ No se pudo transcribir'); }
    } catch (err) { showFeedback('❌ Error de conexion'); }
    finally { setIsTranscribing(false); }
  };

  const handleVoicePress = async () => {
    if (isTranscribing) return;
    if (isRecording) await stopAndTranscribe(); else await startRecording();
  };

  return (
    <View style={s.w}>
      <IncomeAllocationModal isOpen={showModal} onClose={() => setShowModal(false)} amount={incomeAmount} onConfirm={(alloc) => onIncomeAdded?.(incomeAmount, alloc)} currentNeeds={currentNeeds} currentWants={currentWants} currentSavings={currentSavings} totalBalance={totalBalance} />
      {feedback && <View style={s.fb}><Text style={s.fbt}>{feedback}</Text></View>}
      {isTyping && <View style={s.ty}><View style={s.ds}><View style={[s.d, { backgroundColor: COLORS.ROSA }]} /><View style={[s.d, { backgroundColor: COLORS.ROSA_CLARO }]} /><View style={[s.d, { backgroundColor: COLORS.MENTA }]} /></View><Text style={s.tyt}>Tomasa esta calculando...</Text></View>}
      {isFocused && <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.cs} contentContainerStyle={s.cc} keyboardShouldPersistTaps="always">{CHIPS.map((c, i) => <TouchableOpacity key={i} style={[s.cp, c.type === 'income' ? s.ci : s.ce]} onPress={() => { setText(c.label); inputRef.current?.focus(); }}><Text style={c.type === 'income' ? s.cit : s.cet}>{c.label}</Text></TouchableOpacity>)}</ScrollView>}
      <View style={s.b}>
        <TouchableOpacity style={s.m} onPress={handleVoicePress} activeOpacity={0.6} disabled={isTranscribing}><View style={[s.mw, isRecording && s.mr, isTranscribing && s.mt]}><Ionicons name={isTranscribing ? 'hourglass-outline' : isRecording ? 'stop' : 'mic-outline'} size={20} color={isRecording || isTranscribing ? '#fff' : COLORS.ROSA} /></View></TouchableOpacity>
        <TextInput ref={inputRef} style={s.i} value={text} onChangeText={setText} onFocus={() => setIsFocused(true)} onBlur={() => setIsFocused(false)} onSubmitEditing={handleSend} placeholder={isRecording ? '🎙️ Escuchando...' : 'Ej. Pague la luz, Gaste $50...'} placeholderTextColor={COLORS.MALVA + '80'} returnKeyType="send" editable={!isRecording} />
        <TouchableOpacity style={[s.sn, !text.trim() && { opacity: 0.3 }]} onPress={handleSend} disabled={!text.trim()}><Ionicons name="send" size={20} color={COLORS.ROSA} /></TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  w: { gap: 0 },
  fb: { marginHorizontal: 16, marginBottom: 8, backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 16, padding: 12, elevation: 3, borderWidth: 1, borderColor: '#FFCAD460' },
  fbt: { fontSize: 13, fontWeight: '600', color: '#9D8189', lineHeight: 18 },
  ty: { marginHorizontal: 16, marginBottom: 8, backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: 16, padding: 12, gap: 8, elevation: 3 },
  ds: { flexDirection: 'row', gap: 6 }, d: { width: 8, height: 8, borderRadius: 4 },
  tyt: { fontSize: 12, fontWeight: '600', color: '#9D8189' },
  cs: { maxHeight: 44 }, cc: { paddingHorizontal: 16, gap: 8, paddingBottom: 8, alignItems: 'center' },
  cp: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 99, borderWidth: 1 },
  ci: { backgroundColor: '#FFCAD444', borderColor: '#FFCAD4' }, ce: { backgroundColor: 'rgba(255,255,255,0.6)', borderColor: '#fff' },
  cit: { fontSize: 12, fontWeight: '700', color: '#F4ACB7' }, cet: { fontSize: 12, fontWeight: '700', color: '#9D8189' },
  b: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.7)', borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.8)', paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  m: { padding: 4 },
  mw: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFCAD430' },
  mr: { backgroundColor: '#F4ACB7' }, mt: { backgroundColor: '#9D8189' },
  i: { flex: 1, fontSize: 14, fontWeight: '500', color: '#9D8189', backgroundColor: '#fff', borderRadius: 99, paddingHorizontal: 16, paddingVertical: 10, elevation: 2 },
  sn: { padding: 4 },
});
